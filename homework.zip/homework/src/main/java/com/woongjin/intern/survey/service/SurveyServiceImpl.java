package com.woongjin.intern.survey.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.woongjin.intern.survey.dao.SurveyDao;
import com.woongjin.intern.survey.dto.SurveyDto;

@Service("surveyService") 
public class SurveyServiceImpl implements SurveyService{
	
	@Autowired
	private SurveyDao dao;
	@Override
	public void insertSurvey(SurveyDto dto) {
		dao.insertSurvey(dto);
	}

}
