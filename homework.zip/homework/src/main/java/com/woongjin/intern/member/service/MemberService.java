package com.woongjin.intern.member.service;

import java.util.HashMap;
import java.util.List;

import javax.annotation.Resource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.woongjin.intern.member.dao.Dao;
import com.woongjin.intern.member.dto.MemberDto;

@Service("memberService") //MServic memberService = new MemberService(); 컨트롤러에서는 @Resource(name ="memberService")
public class MemberService implements MService {

	@Autowired
	private Dao dao;
	
	@Override
	public List<MemberDto> selectAll() {
		// TODO Auto-generated method stub
		return dao.selectAll();
	}

	@Override
	public MemberDto selectOne(String id) {
		// TODO Auto-generated method stub
		return dao.selectOne(id);
	}

	@Override
	public void insertMember(MemberDto dto) {
		dao.insertMember(dto);
		
	}

	@Override
	public void deleteMember(HashMap<String, String> hashMap) {
		dao.deleteMember(hashMap);
		
	}

	@Override
	public void updateMember(MemberDto dto) {
		dao.updateMember(dto);
		
	}
	@Override
	public List<MemberDto> loginMember(HashMap<String, String> hashMap) {
		// TODO Auto-generated method stub
		return dao.loginMember(hashMap);
	}

	
	

}
