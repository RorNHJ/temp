package com.woongjin.intern.member.dao;

import java.util.HashMap;
import java.util.List;

import com.woongjin.intern.member.dto.MemberDto;

public interface Dao {

	public List<MemberDto> selectAll();
	public MemberDto selectOne(String id);
	public void insertMember(MemberDto dto);
	public void deleteMember(HashMap<String, String> hashMap);
	public void updateMember(MemberDto dto);
	public List<MemberDto> loginMember(HashMap<String, String> hashMap);
}
