package com.woongjin.intern.member.controller;

import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.woongjin.intern.member.dao.Dao;
import com.woongjin.intern.member.dao.MemberDao;
import com.woongjin.intern.member.dto.MemberDto;
import com.woongjin.intern.member.service.MService;

@Controller
@RequestMapping("/member")
public class MemberController {
	@Autowired
	private MemberDao dao;
	
	@Resource(name ="memberService")
	private MService memberService;
	
	@RequestMapping(value="/join_view.do")
	public String join_view() {
		return "/member/join_view";
	}
	

	/**
	 * ajax瑜� �씠�슜�븳 硫ㅻ쾭紐⑸줉由ы꽩
	 * @return
	 * */

	

	
	@RequestMapping(value="/login.do")
	public String login(String mId,String mPw,Model model)  {
		HashMap<String, String> map = new HashMap<String, String>();
		map.put("mId",mId);
		map.put("mPw",mPw);
	
		if(dao.loginMember(map).size() > 0) {
			model.addAttribute("members",dao.loginMember(map));
			return "main";
		}else {
			return "home";
		}
	
	}
	
	@RequestMapping(value="/woongjin_join.do",method=RequestMethod.POST)
	public String woongjin_join(String mId,String mPw, String mName, String mEmail1,String mEmail2,String mPhone,Model model) {
		MemberDto dto = new MemberDto();
		dto.setmId(mId);
		dto.setmName(mName);
		dto.setmPw(mPw);
		dto.setmEmail1(mEmail1);
		dto.setmEmail2(mEmail2);
		dto.setmPhone(mPhone);
		dto.setmPlatForm("woongjin");
		
		SimpleDateFormat formatter = new SimpleDateFormat ("yyyy-MM-dd hh:mm:ss");
		Calendar cal = Calendar.getInstance();
		String today = null;
		today = formatter.format(cal.getTime());
		Timestamp ts = Timestamp.valueOf(today);
		dto.setmJoinDate(ts);
		dao.insertMember(dto);
		return "home";
	}
	
	@RequestMapping(value = "/memberList.json")
	public @ResponseBody Map<String,Object> memberList(){
		Map<String,Object> resultMap = new HashMap<String,Object>();
		resultMap.put("memberList", dao.selectAll());
		return resultMap;
	}
	
	@RequestMapping(value="/kakao_login.do",method=RequestMethod.POST)
	public @ResponseBody Map<String,Object> kakao_login(HttpServletRequest request) {
		MemberDto dto = new MemberDto();
		Map<String, Object> resultMap = new HashMap<String, Object>();
		String mId = request.getParameter("mId");
		String mName= request.getParameter("mName");
		System.out.println("aa " + mId+"  "+mName );
		dto.setmId(mId);
		dto.setmName(mName);
		dto.setmPlatForm("kakao");
		
		SimpleDateFormat formatter = new SimpleDateFormat ("yyyy-MM-dd hh:mm:ss");
		Calendar cal = Calendar.getInstance();
		String today = null;
		today = formatter.format(cal.getTime());
		Timestamp ts = Timestamp.valueOf(today);
		dto.setmJoinDate(ts);
		dao.insertMember(dto);
		resultMap.put("loginName", mName);
		return resultMap;
	}
	@RequestMapping(value="/facebook_login.do",method=RequestMethod.POST)
	public @ResponseBody Map<String,Object> facebook_login(HttpServletRequest request) {
		MemberDto dto = new MemberDto();
		Map<String, Object> resultMap = new HashMap<String, Object>();
		String mId = request.getParameter("mId");
		String mName= request.getParameter("mName");
		System.out.println("aa " + mId+"  "+mName );
		dto.setmId(mId);
		dto.setmName(mName);
		dto.setmPlatForm("facebook");
		
		SimpleDateFormat formatter = new SimpleDateFormat ("yyyy-MM-dd hh:mm:ss");
		Calendar cal = Calendar.getInstance();
		String today = null;
		today = formatter.format(cal.getTime());
		Timestamp ts = Timestamp.valueOf(today);
		dto.setmJoinDate(ts);
		dao.insertMember(dto);
		resultMap.put("login", "success");
		return resultMap;
	}
}
