package com.woongjin.intern.member.dao;

import java.util.HashMap;
import java.util.List;

import javax.annotation.Resource;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.ui.Model;
import com.woongjin.intern.member.dto.MemberDto;

@Repository
public class MemberDao implements Dao{

	@Autowired
	@Resource(name="sqlSession")
	private SqlSession query;
	private final static String MAPPER = "member.memberDao.";
	
	
	@Override
	public List<MemberDto> selectAll() {
		// TODO Auto-generated method stub
		return query.selectList(MAPPER+"selectAll");
	}

	@Override
	public MemberDto selectOne(String id) {
		// TODO Auto-generated method stub
		return query.selectOne(MAPPER+"selectOne",id);
	}

	@Override
	public void insertMember(MemberDto dto) {
		query.insert(MAPPER+"insertMember", dto);
		
	}

	@Override
	public void deleteMember(HashMap<String, String> hashMap) {
		query.insert(MAPPER+"deleteMember", hashMap);
		
	}

	@Override
	public void updateMember(MemberDto dto) {
		query.insert(MAPPER+"updateMember", dto);
		
	}

	@Override
	public List<MemberDto> loginMember(HashMap<String, String> hashMap) {
		return query.selectList(MAPPER+"loginMember",hashMap);
	}
	

}
