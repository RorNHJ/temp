var pos = {
	drawable : false,
	X : -1,
	Y : -1
}
var coors = {

		X : -1,
		Y : -1
}

var json= new Object(); // 데이터보내기...
var start = false; // 게임이 시작되면 true;
var receiveMessage;
var usermode = false; //true: 문제내는 사람, false: 문제를 맞추는 사람
var mode = true; // true : brush mode , false : eraser mode
var main_canvas, ctx;
var brush_size = 1;
var eraser_size = 1;
var wsUri = "ws://localhost:8080/websocket/connect.do";
var websocket = new WebSocket(wsUri);
var messageTextArea = document.getElementById("messageTextArea");
main_canvas = document.getElementById("main_canvas");
ctx = main_canvas.getContext("2d");
main_canvas.addEventListener("mousedown", listener);
main_canvas.addEventListener("mousemove", listener);
main_canvas.addEventListener("mouseup", listener);
main_canvas.addEventListener("mouseout", listener);
document.body.addEventListener("keydown", listener);
document.body.addEventListener("keydown", function(event) {
	if (event.keyCode == '13'){

	}
});

//websocket - 그림판 실시간 커뮤니케이션//

websocket.onopen = function(message) {
	messageTextArea.value += "Server connect...\n";

};
websocket.onclose = function(message) {
	messageTextArea.value += "Server Disconnect...\n";
};
websocket.onerror = function(message) {
	messageTextArea.value += "error...\n";
};
websocket.onmessage = function(message) {
	messageTextArea.value += message.data;

	if(!usermode){
		receiveMessage = JSON.parse(message.data);
		if(receiveMessage.type ==='draw'){
			initDraw();
			ctx.moveTo(receiveMessage.posX, receiveMessage.posY);
			draw();
		}else if(receiveMessage.type ==='clear'){
			console.log(receiveMessage.type);
			ctx.clearRect(receiveMessage.x, receiveMessage.y, receiveMessage.w, receiveMessage.h);
		}
	}

};


// ////////////////////////////////////////////////


function imQuestionUser(){
	alert("Game Start!!");
	usermode = true;
}

function listener(event) {
	if(usermode){
		switch (event.type) {
		case "mousedown":
			initDraw(event);
			break;
		case "mousemove":
			if (pos.drawable)
				draw(event);
			break;
		case "mouseup":
			finishDraw();
			break;
		case "keydown":
			if (event.keyCode == '81')
				mode = true;
			else if (event.keyCode == '87')
				mode = false;
			else if (event.keyCode == '69')
				minus_size();
			else if (event.keyCode == '82')
				plus_size();
		
			break;
		}
	}
}

function initDraw(event) {

	if(usermode){
		ctx.beginPath();
		pos.drawable = true;
		coors = getPosition(event);
		pos.X = coors.X;
		pos.Y = coors.Y;
		ctx.moveTo(pos.X, pos.Y);
	}else{
		ctx.beginPath();
		pos.drawable = true;
	}
}

function draw(event) {
	if(usermode){
		coors = getPosition(event);
		ctx.lineTo(coors.X, coors.Y);
		var strokeStyle =$("#colorPicker").spectrum("get").toHexString();
	
		if (mode) {
			ctx.lineWidth = brush_size;
			
			ctx.strokeStyle = strokeStyle;
		} else {
			ctx.lineWidth = eraser_size;
			ctx.strokeStyle = "#ffffff";
		}
	
		ctx.stroke();
		json.type = "draw";
		json.BlineWidth =brush_size;
		json.ElineWidth =eraser_size;
		json.mode = mode;
		json.strokeStyle = strokeStyle;
		json.posX= pos.X;
		json.posY= pos.Y;
		json.coorsX= coors.X;
		json.coorsY= coors.Y;
		websocket.send(JSON.stringify(json));
		pos.X = coors.X;
		pos.Y = coors.Y;
	}else{
		ctx.lineTo(receiveMessage.coorsX, receiveMessage.coorsY);
		if (receiveMessage.mode) {
			ctx.lineWidth = receiveMessage.BlineWidth;
			
			ctx.strokeStyle = receiveMessage.strokeStyle;
		} else {
			ctx.lineWidth = receiveMessage.ElineWidth;
			ctx.strokeStyle = "#ffffff";
		}
		ctx.stroke();
	}
}
function finishDraw() {
	pos.drawable = false;
	pos.X = -1;
	pos.Y = -1;
}
function getPosition(event) {
	var x = event.pageX - main_canvas.offsetLeft;
	var y = event.pageY - main_canvas.offsetTop;
	return {
		X : x,
		Y : y
	};
}

$(function() {
	$("#colorPicker").spectrum({
		showPalette : true,
		palette : [],
		showButtons : false,
		showSelectionPalette : true, // true by default
		selectionPalette : [ "red", "green", "blue", "yellow" ]
	});
});

$("#brush_btn").click(function() {
	mode = true;
	document.getElementById('question').innerHTML = "hihi";

});
$("#eraser_btn").click(function() {
	mode = false;
});
$("#minus_btn").click(function() {
	minus_size();
});

$("#plus_btn").click(function() {
	plus_size();
});

$("#allEraser_btn").click(function() {
	ctx.clearRect(0, 0, 600, 500);
	json.type = "clear";
	json.x = 0;
	json.y= 0;
	json.w=600;
	json.h=500;
	websocket.send(JSON.stringify(json));
});

function plus_size() {
	if (mode) {
		if (brush_size <= 30)
			brush_size = brush_size + 1;
	} else {
		if (eraser_size <= 30)
			eraser_size = eraser_size + 1;
	}
}
function minus_size() {
	if (mode) {
		if (brush_size >= 1)
			brush_size = brush_size - 1;
	} else {
		if (eraser_size >= 1)
			eraser_size = eraser_size - 1;
	}
}


