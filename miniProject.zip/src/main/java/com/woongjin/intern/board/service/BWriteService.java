package com.woongjin.intern.board.service;

import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.springframework.ui.Model;

import com.woongjin.intern.board.dao.BDao;

public class BWriteService implements BService{

	@Override
	public void execute(Model model) {
		Map<String, Object> map  = model.asMap();
		HttpServletRequest request =(HttpServletRequest)map.get("request");
		
		String mId= request.getParameter("mId");
		String bTitle= request.getParameter("bTitle");
		String bContent= request.getParameter("bContent");

		BDao dao = new BDao();
		dao.write(mId,bTitle,bContent);
	}
	

}
