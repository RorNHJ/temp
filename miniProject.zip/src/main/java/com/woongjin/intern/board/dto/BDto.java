package com.woongjin.intern.board.dto;

import java.sql.Timestamp;

public class BDto {

	private int bId;
	private String mId;
	private String bTitle;
	private String bContent;
	private int bView;
	private int bLike;
	private Timestamp bDate;
	
	public BDto() {
		super();
		// TODO Auto-generated constructor stub
	}
	public BDto(int bId, String mId, String bTitle, String bContent, int bView, int bLike, Timestamp bDate) {
		super();
		this.bId = bId;
		this.mId = mId;
		this.bTitle = bTitle;
		this.bContent = bContent;
		this.bView = bView;
		this.bLike = bLike;
		this.bDate = bDate;
	}
	public int getbId() {
		return bId;
	}
	public void setbId(int bId) {
		this.bId = bId;
	}
	public String getmId() {
		return mId;
	}
	public void setmId(String mId) {
		this.mId = mId;
	}
	public String getbTitle() {
		return bTitle;
	}
	public void setbTitle(String bTitle) {
		this.bTitle = bTitle;
	}
	public String getbContent() {
		return bContent;
	}
	public void setbContent(String bContent) {
		this.bContent = bContent;
	}
	public int getbView() {
		return bView;
	}
	public void setbView(int bView) {
		this.bView = bView;
	}
	public int getbLike() {
		return bLike;
	}
	public void setbLike(int bLike) {
		this.bLike = bLike;
	}
	public Timestamp getbDate() {
		return bDate;
	}
	public void setbDate(Timestamp bDate) {
		this.bDate = bDate;
	}
	
	
	
}
