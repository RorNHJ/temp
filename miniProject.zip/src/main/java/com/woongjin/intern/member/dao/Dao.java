package com.woongjin.intern.member.dao;

import java.util.ArrayList;
import java.util.List;

import com.woongjin.intern.member.dto.MemberDto;

public interface Dao {

	public List<MemberDto> showMemberDao();
	public void insertMemberDao(MemberDto dto);
	public MemberDto updateMemberDao(MemberDto dto);
	public void deleteMemberDao(String mId, String mPw);
}
