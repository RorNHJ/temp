package com.woongjin.intern.member.controller;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.woongjin.intern.member.dao.Dao;
import com.woongjin.intern.member.dao.MemberDao;
import com.woongjin.intern.member.dto.MemberDto;

@Controller
@RequestMapping("/member")
public class MemberController {
	@Autowired
	private MemberDao dao;
	
	@Autowired
	private SqlSession sqlSession;
	

	@RequestMapping(value="/showMember.do")
	public String showMember(Model model) {
		MemberDao dao = sqlSession.getMapper(MemberDao.class);
		model.addAttribute("allMember",dao.showMemberDao());
		return "../member/showMember";
	}
}
