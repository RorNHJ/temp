package com.woongjin.intern.member.dao;

import java.util.ArrayList;
import java.util.List;

import javax.annotation.Resource;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.woongjin.intern.member.dto.MemberDto;

@Repository
public class MemberDao implements Dao{
	@Autowired
	@Resource
	private SqlSession query;
	private final static String Mapper = "member.dao.Dao.";
	@Override
	public List<MemberDto> showMemberDao() {
		// TODO Auto-generated method stub
		return query.selectList(Mapper+"showMemberDao");
	}
	@Override
	public void insertMemberDao(MemberDto dto) {
		// TODO Auto-generated method stub
		
	}
	@Override
	public MemberDto updateMemberDao(MemberDto dto) {
		// TODO Auto-generated method stub
		return null;
	}
	@Override
	public void deleteMemberDao(String mId, String mPw) {
		// TODO Auto-generated method stub
		
	}
	

}
