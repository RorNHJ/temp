package com.woongjin.intern.member.dto;

import java.sql.Timestamp;

public class MemberDto {
	String mName;
	String mId;
	String mPw;
	String mPhone;
	String mEmail;
	Timestamp mJoinDate; // 가입날짜
	
	
	public MemberDto() {
		super();
	}
	
	public MemberDto(String mName, String mId, String mPw, String mPhone, String mEmail, Timestamp mJoinDate) {
		super();
		this.mName = mName;
		this.mId = mId;
		this.mPw = mPw;
		this.mPhone = mPhone;
		this.mEmail = mEmail;
		this.mJoinDate = mJoinDate;
	}
	public String getmName() {
		return mName;
	}
	public void setmName(String mName) {
		this.mName = mName;
	}
	public String getmId() {
		return mId;
	}
	public void setmId(String mId) {
		this.mId = mId;
	}
	public String getmPw() {
		return mPw;
	}
	public void setmPw(String mPw) {
		this.mPw = mPw;
	}
	public String getmPhone() {
		return mPhone;
	}
	public void setmPhone(String mPhone) {
		this.mPhone = mPhone;
	}
	public String getmEmail() {
		return mEmail;
	}
	public void setmEmail(String mEmail) {
		this.mEmail = mEmail;
	}
	public Timestamp getmJoinDate() {
		return mJoinDate;
	}
	public void setmJoinDate(Timestamp mJoinDate) {
		this.mJoinDate = mJoinDate;
	}
	
	
}
