package com.woongjin.intern.member.service;

import org.springframework.ui.Model;

public interface MemberService {
	void execute(Model model);
}
