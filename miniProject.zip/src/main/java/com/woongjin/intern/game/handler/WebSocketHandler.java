package com.woongjin.intern.game.handler;

import java.util.HashSet;
import java.util.Set;

import org.springframework.beans.factory.InitializingBean;
import org.springframework.web.socket.BinaryMessage;
import org.springframework.web.socket.CloseStatus;
import org.springframework.web.socket.PongMessage;
import org.springframework.web.socket.TextMessage;
import org.springframework.web.socket.WebSocketMessage;
import org.springframework.web.socket.WebSocketSession;
import org.springframework.web.socket.handler.TextWebSocketHandler;

public class WebSocketHandler extends TextWebSocketHandler implements InitializingBean{
	private Set<WebSocketSession> sessionSet = new HashSet<WebSocketSession>();
	@Override
	public void afterPropertiesSet() throws Exception {
		// TODO Auto-generated method stub
		
	}

	@Override
	protected void handleBinaryMessage(WebSocketSession session, BinaryMessage message) {
		// TODO Auto-generated method stub
		super.handleBinaryMessage(session, message);
	}

//	WebSocket 연결이 열리고 사용이 준비될 때 호출
	@Override
	public void afterConnectionEstablished(WebSocketSession session) throws Exception {
		// TODO Auto-generated method stub
		super.afterConnectionEstablished(session);
		sessionSet.add(session);
		System.out.println("클라이언트 접속: "+ session.getId());
	}
	
	
//	WebSocket 연결이 닫혔을 때 호출
	@Override
	public void afterConnectionClosed(WebSocketSession session, CloseStatus status) throws Exception {
		// TODO Auto-generated method stub
		super.afterConnectionClosed(session, status);
		System.out.println("클라이언트 퇴장: " +session.getId() );
		
		sessionSet.remove(session);
		
	}

//	클라이언트로부터 메시지가 도착했을 때 호출
	@Override
	public void handleMessage(WebSocketSession session, WebSocketMessage<?> message) throws Exception {
		// TODO Auto-generated method stub
		super.handleMessage(session, message);
		System.out.println("receive message //  session: "+session.getId()+  ":  "+message.toString());
		sendMessage(session,message);
	}

//	전송 에러 발생할 때 호출
	@Override
	public void handleTransportError(WebSocketSession session, Throwable exception) throws Exception {
		// TODO Auto-generated method stub
		super.handleTransportError(session, exception);
	}


//	WebSocketHandler가 부분 메시지를 처리할 때 호출
	@Override
	public boolean supportsPartialMessages() {
		// TODO Auto-generated method stub
		return super.supportsPartialMessages();
	}
	
	  public void sendMessage (WebSocketSession mysession,WebSocketMessage<?> message){
          for (WebSocketSession session: this.sessionSet){
                 if (session.isOpen() && !session.equals(mysession)){ //본인 빼고 다른 사람들한테 전달
                        try{
                              session.sendMessage(message);
                        }catch (Exception e){
                        	e.printStackTrace();
                        }
                 }
          }
    }
	

}
