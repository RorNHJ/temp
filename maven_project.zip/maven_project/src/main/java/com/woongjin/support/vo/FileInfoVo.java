package com.woongjin.support.vo;
import java.util.List;

import org.springframework.web.multipart.MultipartFile;

public class FileInfoVo {
	private String fileId;
	private String orgFileName;
	private String contentType;
	private long fileSize;
	private String filePath;
	private String registId;	
	private List<MultipartFile> multiPartFiles;
	public String getFileId() {
		return fileId;
	}
	public void setFileId(String fileId) {
		this.fileId = fileId;
	}
	public String getOrgFileName() {
		return orgFileName;
	}
	public void setOrgFileName(String orgFileName) {
		this.orgFileName = orgFileName;
	}

	public long getFileSize() {
		return fileSize;
	}
	public void setFileSize(long fileSize) {
		this.fileSize = fileSize;
	}
	public String getFilePath() {
		return filePath;
	}
	public void setFilePath(String filePath) {
		this.filePath = filePath;
	}
	public String getRegistId() {
		return registId;
	}
	public void setRegistId(String registId) {
		this.registId = registId;
	}

	public List<MultipartFile> getMultiPartFiles() {
		return multiPartFiles;
	}
	public void setMultiPartFiles(List<MultipartFile> multiPartFiles) {
		this.multiPartFiles = multiPartFiles;
	}
	public String getContentType() {
		return contentType;
	}
	public void setContentType(String contentType) {
		this.contentType = contentType;
	}
	
	
	
}
