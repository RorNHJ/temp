package com.woongjin.support.dao;

import java.util.List;

import com.woongjin.support.vo.FileInfoVo;
import com.woongjin.util.Search;

public interface FileInfoDao {
	public List<FileInfoVo> selectList();
	public int selectListCount(Search search);
	public void insert(FileInfoVo vo);

	public FileInfoVo select(String str);
	public void delete(String fileId);


}
