package com.woongjin.home.dto;

public class BoardDto {
	String BoardId;
	String writerId;
	
	String title;
	String content;
	String view;
	String like;
	public BoardDto() {
		super();
		// TODO Auto-generated constructor stub
	}
	public BoardDto(String boardId, String writerId, String title, String content, String view, String like) {
		super();
		BoardId = boardId;
		this.writerId = writerId;
		this.title = title;
		this.content = content;
		this.view = view;
		this.like = like;
	}
	public String getBoardId() {
		return BoardId;
	}
	public void setBoardId(String boardId) {
		BoardId = boardId;
	}
	public String getWriterId() {
		return writerId;
	}
	public void setWriterId(String writerId) {
		this.writerId = writerId;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public String getContent() {
		return content;
	}
	public void setContent(String content) {
		this.content = content;
	}
	public String getView() {
		return view;
	}
	public void setView(String view) {
		this.view = view;
	}
	public String getLike() {
		return like;
	}
	public void setLike(String like) {
		this.like = like;
	}
	

}
