package com.woongjin.home.dao.impl;

import java.util.HashMap;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.woongjin.home.service.HomeService;
import com.woongjin.home.vo.HomeVo;
import com.woongjin.util.Search;
@Service
public class HomeServiceImpl implements HomeService{
	@Autowired
	private HomeDaoImpl homeDao;
	@Override
	public List<HomeVo> selectList(Search paging){
//		homeDao= new HomeDaoImpl();
		return homeDao.selectList(paging);
	}
	@Override
	public int selectListCount(Search search) {
		// TODO Auto-generated method stub
		return homeDao.selectListCount(search);
	}
	@Override
	public void insertData(HomeVo homeVo) {
		homeDao.insertData(homeVo);
		
	}
	@Override
	public void deleteData(HashMap<String, String> hashMap ) {
		homeDao.deleteData(hashMap);
		
	}
	@Override
	public void updateData(HomeVo homeVo) {
		homeDao.updateData(homeVo);
		
	}
	@Override
	public HomeVo selectMember(String id) {
		return homeDao.selectMember(id);
	}
	
	
	
}
