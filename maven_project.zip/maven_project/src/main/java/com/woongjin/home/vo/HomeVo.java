package com.woongjin.home.vo;

import java.io.Serializable;

public class HomeVo implements Serializable{
	
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private String id;
	private String name;
	private String pw;
	private String email1;
	private String email2;
	private String phone;
	
	
	
	
	public HomeVo() {
		super();
		// TODO Auto-generated constructor stub
	}
	public HomeVo(String id, String name, String pw, String email1, String email2, String phone) {
		super();
		this.id = id;
		this.name = name;
		this.pw = pw;
		this.email1 = email1;
		this.email2 = email2;
		this.phone = phone;
	}
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getPw() {
		return pw;
	}
	public void setPw(String pw) {
		this.pw = pw;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}

	public String getEmail1() {
		return email1;
	}
	public void setEmail1(String email1) {
		this.email1 = email1;
	}
	public String getEmail2() {
		return email2;
	}
	public void setEmail2(String email2) {
		this.email2 = email2;
	}
	public String getPhone() {
		return phone;
	}
	public void setPhone(String phone) {
		this.phone = phone;
	}


}
