package com.woongjin.home.service;

import java.util.ArrayList;

import org.springframework.ui.Model;

import com.woongjin.home.dto.MemberDto;

public interface BService {
	 public ArrayList<MemberDto> execute(Model model);
}
