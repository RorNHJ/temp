package com.woongjin.home.controller;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.woongjin.home.service.HomeService;
import com.woongjin.home.vo.HomeVo;
import com.woongjin.util.Search;
@Controller
@RequestMapping(value="/")
public class HomeController {
	
	@Autowired
	private HomeService homeService;
	
	@RequestMapping(value="/")
	public ModelAndView show(Search search) {
		

		ModelAndView view = new ModelAndView("index");

		view.addObject("hello","aaaaaaaaa");
		return view;
	}
	
	@RequestMapping(value="/showMessage5.do")
	public ModelAndView showMessage5(Search search) {
		
		search.calculate(homeService.selectListCount(search));

		ModelAndView view = new ModelAndView("showMessage");

		view.addObject("search",search);
		view.addObject("list",homeService.selectList(search));
		return view;
	}

	

  	/**
	 * ajax를 이용한 멤버목록리턴
	 * @return
	 * */
	@RequestMapping(value = "/memberList.json")
	public @ResponseBody Map<String,Object> memberList(Search search){
		Map<String,Object> resultMap = new HashMap<String,Object>();
		search.calculate(homeService.selectListCount(search));
		
		resultMap.put("memberList", homeService.selectList(search));
		return resultMap;
	}
	
	@RequestMapping(value="/insertMember.do",method=RequestMethod.POST)
	public String insertMember(HttpServletRequest httpServletRequest) {
		System.out.println("RequestMethod.POST");
	
        String id = httpServletRequest.getParameter("id");
        String name = httpServletRequest.getParameter("name");
        String pw = httpServletRequest.getParameter("pw");
        String email1 = httpServletRequest.getParameter("email1");
        String email2 = httpServletRequest.getParameter("email2");
        String phone = httpServletRequest.getParameter("phone");
//        
        HomeVo homeVo = new HomeVo(id,name,pw,email1,email2,phone);
        homeService.insertData(homeVo);
        return "redirect:showMessage5.do";
   
	}
	@RequestMapping(value="/deleteMember.do",method=RequestMethod.POST)
	public String deleteMember(HttpServletRequest httpServletRequest) {
		System.out.println("RequestMethod.POST");
		HashMap<String, String> map = new HashMap<String, String>();
        String id = httpServletRequest.getParameter("id");
        String pw = httpServletRequest.getParameter("pw");
        HashMap<String, String> hashMap = new HashMap<>();
        hashMap.put("id", id );
        hashMap.put("pw", pw );

        System.out.println(hashMap.get("id") + hashMap.get("pw"));
        homeService.deleteData(hashMap);
        
        return "redirect:showMessage5.do";
   
	}
	
	@RequestMapping(value="/updateMember.do",method=RequestMethod.POST)
	public String updateMember(HomeVo homeVo) {
        homeService.updateData(homeVo);
        
        return "redirect:showMessage5.do";
   
	}
	
	@RequestMapping(value="/modify_view.do")
//	public String modify_view(@RequestParam("id") String paramId,Model model) {
	public ModelAndView modify_view(@RequestParam(value="id") String paramId,Model model) {
		System.out.println("paramId  " + paramId);
		ModelAndView view = new ModelAndView("modify_view");
		view.addObject("content",homeService.selectMember(paramId));
		return view;
   
	}
	
	
	
	
	
	@RequestMapping(value="/showMessage.do")
	public String showMessage(ModelMap modelMap) {
		modelMap.put("message", "Hello!!!");
		return "hello";
	}

	@RequestMapping(value="/testIOException.do")
	public String testIOException() throws IOException{
		if(true) throw new IOException("this is an IOexception");
		return "showMessage";
	}

	@RequestMapping(value="/showMessage2.do")
	public @ResponseBody String showMessage2(ModelMap modelMap){

		return "<html>"
				+ "<head>"
				+ "<title>hyunji</title>"
				+ "</head>"
				+"<body>"
				+ "<h1>안녕하세요!!!!!!!!!!</h1>"
				+ "</body>"
				+ "</html>";
	}
	
}
