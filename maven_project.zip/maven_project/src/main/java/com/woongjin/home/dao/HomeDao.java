package com.woongjin.home.dao;



import java.util.HashMap;
import java.util.List;

import org.springframework.stereotype.Service;

import com.woongjin.home.vo.HomeVo;
import com.woongjin.util.Search;
@Service
public interface HomeDao {
	public List<HomeVo> selectList(Search search);
	public int selectListCount(Search search);
	public void insertData(HomeVo homeVo);
	public void updateData(HomeVo homeVo);
	public void deleteData(HashMap<String, String> HashMap);
	public HomeVo selectMember(String id);
}
