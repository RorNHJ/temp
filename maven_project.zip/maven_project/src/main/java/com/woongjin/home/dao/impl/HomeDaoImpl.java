package com.woongjin.home.dao.impl;

import java.util.HashMap;
import java.util.List;

import javax.annotation.Resource;

import org.mybatis.spring.SqlSessionTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.woongjin.home.dao.HomeDao;
import com.woongjin.home.vo.HomeVo;
import com.woongjin.util.Search;
@Repository
public class HomeDaoImpl implements HomeDao {
	@Autowired
	@Resource
    private SqlSessionTemplate query;
	private final static String Mapper = "home.homeDao.";
	@Override
	public List<HomeVo> selectList(Search search) {
		return query.selectList(Mapper+"selectList",search);
	}
	
	@Override
	public int selectListCount(Search search) {
		return query.selectOne(Mapper+"selectListCount",search);
	}

	@Override
	public void insertData(HomeVo homeVo) {
		int result =query.insert(Mapper+"insertData", homeVo);
	
		
	}
	@Override
	public void deleteData(HashMap<String, String> hashMap) {
		int result =query.delete(Mapper+"deleteData",hashMap);
		
		
	}
	@Override
	public void updateData(HomeVo homeVo) {
		int result =query.update(Mapper+"updateData",homeVo);
		
	}
	@Override
	public HomeVo selectMember(String id) {
		return query.selectOne(Mapper+"selectMember",id);
	}
	
	
	
	

}
