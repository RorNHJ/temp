package com.woongjin.board.dao;

import java.util.List;

import com.woongjin.board.search.GuestBoardSearch;
import com.woongjin.board.vo.GuestBoardVo;

public interface GuestBoardDao {
	public List<GuestBoardVo> selectList(GuestBoardSearch search);
	public int selectListCount(GuestBoardSearch search);
	
	public GuestBoardVo select(String guestBookId);
	public void insert (GuestBoardVo vo);
	public void delete (GuestBoardVo vo);
	public void update (GuestBoardVo vo);
	public String selectLastRecord();
}
