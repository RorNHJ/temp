package com.woongjin.board.vo;

import java.io.Serializable;

public class GuestBoardVo implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -8533080120775262965L;
	private String guestBookId;
	private String title;
	private String content;
	private String password;
	private String registerId;
	private String registDate;
	private String updaterId;
	private String updateDate;
	public String getGuestBookId() {
		return guestBookId;
	}
	public void setGuestBookId(String guestBookId) {
		this.guestBookId = guestBookId;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public String getContent() {
		return content;
	}
	public void setContent(String content) {
		this.content = content;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getRegisterId() {
		return registerId;
	}
	public void setRegisterId(String registerId) {
		this.registerId = registerId;
	}
	public String getRegistDate() {
		return registDate;
	}
	public void setRegistDate(String registDate) {
		this.registDate = registDate;
	}
	public String getUpdaterId() {
		return updaterId;
	}
	public void setUpdaterId(String updaterId) {
		this.updaterId = updaterId;
	}
	public String getUpdateDate() {
		return updateDate;
	}
	public void setUpdateDate(String updateDate) {
		this.updateDate = updateDate;
	}
	
}
