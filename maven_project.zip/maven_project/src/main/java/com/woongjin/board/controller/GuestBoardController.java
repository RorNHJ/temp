package com.woongjin.board.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.woongjin.board.search.GuestBoardSearch;
import com.woongjin.board.service.GuestBoardService;
import com.woongjin.board.vo.GuestBoardVo;

@Controller
@RequestMapping(value="/board")
public class GuestBoardController {
	@Autowired
	private GuestBoardService guestBoardService;
	
	@RequestMapping(value="/list.do")
	public ModelAndView list(GuestBoardSearch search) {
		
		search.calculate(guestBoardService.selectListCount(search));
		ModelAndView view = new ModelAndView("/board/board_main");

		view.addObject("search",search);
		view.addObject("list",guestBoardService.selectList(search));
		return view;
	}
	
	
	@RequestMapping(value="/insertForm.do")
	public String insertForm() {

		return "/board/insertForm";
	}
	@RequestMapping(value="/insert.do")
	public String insert(GuestBoardVo guestBoardVo) {
		guestBoardVo.setGuestBookId(createID());
		guestBoardService.insert(guestBoardVo);
	
		return "redirect:/board/list.do";
	}
	public String createID() {


		String columId = guestBoardService.selectLastRecord();
		String substring_int_columId = columId.substring(5,columId.length() );
		String substring_str_columId = columId.substring(0,5);
		
		int transInt_surId = Integer.parseInt(substring_int_columId);

		String prefix = String.format("%04d",transInt_surId+1); 
		columId=substring_str_columId+prefix;
		
		return columId;
	}
}
