package com.woongjin.user.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.woongjin.user.dto.UserInfoVo;
import com.woongjin.util.Search;
@Service
public interface UserService {
	public List<UserInfoVo> selectList(Search search);
	public int selectListCount(Search search);
	public void insert(UserInfoVo userInfoVo);
	public void update(UserInfoVo userInfoVo) throws Exception;
	public void delete(String string);
	public UserInfoVo select(Search search);
	public UserInfoVo selectMember(String string);
}
