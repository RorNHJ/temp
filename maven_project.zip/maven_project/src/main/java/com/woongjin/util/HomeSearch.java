package com.woongjin.util;

public class HomeSearch extends Search {

}
