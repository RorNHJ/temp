package com.woongjin.login.controller;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.woongjin.login.dto.LoginDto;
import com.woongjin.user.dto.UserInfoVo;
import com.woongjin.user.service.UserService;
import com.woongjin.util.BaseController;
import com.woongjin.util.EncryptUtil;

@Controller
@RequestMapping(value="/login")
public class LoginController extends BaseController {

	@Autowired
	private UserService userService;
	@RequestMapping(value = "/loginForm.do")
	public String loginForm(
		@RequestParam(value="errorMessage",required=false,defaultValue="")String errorMessage, Model model) {
		model.addAttribute("errorMessage", errorMessage);
		return "/login/loginForm";
	}
	
	/*로그인*/
	@RequestMapping(value = "/login.do")
	public ModelAndView login(LoginDto loginDto) throws Exception {
		System.out.println(loginDto.getmId()+ "   //    " );
		UserInfoVo userInfo = userService.selectMember(loginDto.getmId());
		System.out.println(loginDto.getmId()+ "   //    " + userInfo.getUserId() );
		
		ModelAndView view = new ModelAndView("redirect:/user/search.do");
		if(userInfo == null) {
			view.setViewName("redirect:/login/loginForm.do");
			view.addObject("errorMessage","사용자가 존재하지 않습니다.");
			return view;
		}
		
		String encPw = EncryptUtil.getEncMD5(loginDto.getmPw());
		if(!userInfo.getPassword().equalsIgnoreCase(encPw)){
			view.setViewName("redirect:/login/loginForm.do");
			view.addObject("errorMessage","사용자 정보를 확인해주세요 ");
			return view;
		}
		
		setRequestAttribut("userInfo", userInfo);
		setRequestAttribut("userId", loginDto.getmId());
		return view;

	}	
	
	/*로그아웃*/
	@RequestMapping(value = "/logout.do")
	public ModelAndView logout(HttpSession session) {
		session.invalidate();
		ModelAndView view = new ModelAndView("login/loginForm");
		return view;
	}
	



}
