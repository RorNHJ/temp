package maven_project;

import com.woongjin.util.EncryptUtil;

public class EncryptUtilTest {
	public static void main(String[] args) {
		try {
			System.out.println(EncryptUtil.getEncMD5("1234"));
		}catch (Exception e) {
			e.printStackTrace();
		}
	}

}
