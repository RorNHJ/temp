

function modifyBoard(boardId) {
	var pw = $("#password").val();
	$.ajax({
		type : "post",
		dataType : "json",
		url : "/board/passwordCheck.do",
		data : {
			guestBookId : boardId,
			password : pw
		},
		success : function(data) {
			location.href = "/board/modifyForm.do?e";
		},
		error : function(data) {
			alert("비밀번호가 틀립니다. 수정 불가능");
		}
	});
}
function deleteBoard(boardId) {
	var pw = $("#password").val();
	$.ajax({
		type : "post",
		dataType : "json",
		url : "/board/passwordCheck.do",
		data : {
			guestBookId : boardId,
			password : pw
		},
		success : function(data) {
			location.href = "/board/delete.do";
		},
		error : function(data) {
			alert("비밀번호가 틀립니다. 삭제 불가능");
		}
	});
}

$('#modifyBoard').click(function() {
	var password = $("#password").val();
	$.ajax({
		type : "post",
		dataType : "json",
		url : "/board/passwordCheck.do",
		data : {
			paramPw : password
		},
		success : function(data) {
			location.href = "/board/modifyForm.do";
		},
		error : function(data) {
			alert("비밀번호가 틀립니다. 수정 불가능");
		}
	});
});
$('#deleteBoard').click(function() {
	var password = $("#password").val();
	$.ajax({
		type : "post",
		dataType : "json",
		url : "/board/passwordCheck.do",
		data : {
			paramPw : password
		},
		success : function(data) {
			location.href = "/board/delete.do";
		},
		error : function(data) {
			alert("비밀번호가 틀립니다. 삭제 불가능");
		}
	});
});