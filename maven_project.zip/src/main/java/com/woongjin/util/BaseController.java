package com.woongjin.util;

import org.springframework.web.context.request.RequestAttributes;
import org.springframework.web.context.request.RequestContextHolder;

public abstract class BaseController {
	/*세션 값 가져옴*/
	public Object getRequestAttribut(String name) {
		return RequestContextHolder.currentRequestAttributes().getAttribute(name, RequestAttributes.SCOPE_SESSION);
		
	}
	/*세션 값 등록*/
	public void setRequestAttribut(String name,Object value) {
		RequestContextHolder.currentRequestAttributes().setAttribute(name,value ,RequestAttributes.SCOPE_SESSION);
		
	}
	/*세션 값 삭제*/
	public void removeRequestAttribut(String name) {
		RequestContextHolder.currentRequestAttributes().removeAttribute(name,RequestAttributes.SCOPE_SESSION);
		
	}
}
