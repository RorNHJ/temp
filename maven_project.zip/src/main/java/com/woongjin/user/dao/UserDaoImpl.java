package com.woongjin.user.dao;

import java.util.List;

import javax.annotation.Resource;

import org.mybatis.spring.SqlSessionTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.woongjin.user.dto.UserInfoVo;
import com.woongjin.util.Search;
@Repository
public class UserDaoImpl implements UserDao {
	@Autowired
	@Resource(name="sqlSessionTemplate")
    private SqlSessionTemplate query;
	private final static String Mapper = "user.userDao.";
	
	
	@Override
	public void insert(UserInfoVo userInfoVo) {
		query.insert(Mapper+"insert", userInfoVo);
		
	}

	@Override
	public void update(UserInfoVo userInfoVo) {
		query.update(Mapper+"update",userInfoVo);
		
	}


	@Override
	public UserInfoVo select(Search search) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<UserInfoVo> selectList(Search search) {
		return query.selectList(Mapper+"selectList",search);
	}
	
	@Override
	public int selectListCount(Search search) {
		return query.selectOne(Mapper+"selectListCount",search);
	}

	@Override
	public void delete(String string) {
		query.delete(Mapper+"delete",string);
		
	}

	@Override
	public UserInfoVo selectMember(String string) {
		// TODO Auto-generated method stub
		return query.selectOne(Mapper+"selectMember",string);
	}

	
	
	

}
