package com.woongjin.user.dao;



import java.util.List;

import com.woongjin.user.dto.UserInfoVo;
import com.woongjin.util.Search;
public interface UserDao {
	public List<UserInfoVo> selectList(Search search);
	public int selectListCount(Search search);
	public void insert(UserInfoVo userInfoVo);
	public void update(UserInfoVo userInfoVo);
	public void delete(String string);
	public UserInfoVo selectMember(String string);
	public UserInfoVo select(Search search);
}
