package com.woongjin.user.controller;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.woongjin.user.dto.UserInfoVo;
import com.woongjin.user.service.UserService;
import com.woongjin.util.EncryptUtil;
import com.woongjin.util.Search;
@Controller
@RequestMapping(value="/user")
public class UserController {
	
	@Autowired
	private UserService userService;
	@RequestMapping(value="/view.do")
	public String view() {

		return "userInfo/view";
	}
	
	@RequestMapping(value="/insertForm.do")
	public String insertForm() {

		return "userInfo/insertForm";
	}
	@RequestMapping(value="/list.do")
	public String list() {

		return "redirect:/user/search.do";
	}
	@RequestMapping(value="/insert.do",method=RequestMethod.POST)
	public String insert(UserInfoVo userInfoVo) throws Exception { 
		
		userInfoVo.setPassword(EncryptUtil.getEncMD5(userInfoVo.getPassword()));
		
        userService.insert(userInfoVo);
        return "redirect:/user/search.do";
   
	}
	
	
	@RequestMapping(value="/search.do")
	public ModelAndView showMessage5(Search search) {
		
		search.calculate(userService.selectListCount(search));

		ModelAndView view = new ModelAndView("userInfo/list");

		view.addObject("search",search);

		view.addObject("list",userService.selectList(search));
		return view;
	}

	

  	/**
	 * ajax를 이용한 멤버목록리턴
	 * @return
	 * */
	@RequestMapping(value = "/memberList.json")
	public @ResponseBody Map<String,Object> memberList(Search search){
		Map<String,Object> resultMap = new HashMap<String,Object>();
		search.calculate(userService.selectListCount(search));
		
		resultMap.put("memberList", userService.selectList(search));
		return resultMap;
	}

	@RequestMapping(value="/delete.do")
	public String deleteMember(HttpServletRequest httpServletRequest) {

        String id = httpServletRequest.getParameter("id");

        userService.delete(id);
        
        return "redirect:/user/search.do";
   
	}
	
	@RequestMapping(value="/update.do",method=RequestMethod.POST)
	public String updateMember(UserInfoVo userInfoVo) throws Exception {
        userService.update(userInfoVo);
        
        return "redirect:/user/search.do";
   
	}
	
	@RequestMapping(value="/updateForm.do")
	public ModelAndView updateForm(@RequestParam(value="id") String userId,Model model) {
		System.out.println("userId  " + userId);
		ModelAndView view = new ModelAndView("userInfo/updateForm");
		view.addObject("content",userService.selectMember(userId));
		return view;
   
	}
	
	@RequestMapping(value="/testIOException.do")
	public String testIOException() throws IOException{
		if(true) throw new IOException("this is an IOexception");
		return "showMessage";
	}

	@RequestMapping(value="/showMessage2.do")
	public @ResponseBody String showMessage2(ModelMap modelMap){

		return "<html>"
				+ "<head>"
				+ "<title>hyunji</title>"
				+ "</head>"
				+"<body>"
				+ "<h1>안녕하세요!!!!!!!!!!</h1>"
				+ "</body>"
				+ "</html>";
	}
	
}
