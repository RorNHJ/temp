package com.woongjin.user.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.woongjin.user.dao.UserDaoImpl;
import com.woongjin.user.dto.UserInfoVo;
import com.woongjin.util.EncryptUtil;
import com.woongjin.util.Search;
@Service("userService")
public class UserServiceImpl implements UserService{
	@Autowired
	private UserDaoImpl Dao;

	@Override
	public List<UserInfoVo> selectList(Search search) {
		// TODO Auto-generated method stub
		return Dao.selectList(search);
	}

	@Override
	public int selectListCount(Search search) {
		// TODO Auto-generated method stub
		return Dao.selectListCount(search);
	}
	@Override
	public UserInfoVo  selectMember(String string) {
		return Dao.selectMember(string);
		
	}

	@Override
	public void insert(UserInfoVo userInfoVo) {
		Dao.insert(userInfoVo);
		
	}

	@Override
	public void update(UserInfoVo userInfoVo) throws Exception {
		userInfoVo.setPassword(EncryptUtil.getEncMD5(userInfoVo.getPassword()));
		Dao.update(userInfoVo);
		
	}

	@Override
	public void delete(String string) {
		Dao.delete(string);
		
	}

	@Override
	public UserInfoVo select(Search search) {
		// TODO Auto-generated method stub
		return null;
	}


	
	
	
	
	
	
	
	

/*	public List<HomeVo> selectList(Search paging){
//		homeDao= new HomeDaoImpl();
		return homeDao.selectList(paging);
	}

	public int selectListCount(Search search) {
		// TODO Auto-generated method stub
		return homeDao.selectListCount(search);
	}

	public void insertData(HomeVo homeVo) {
		homeDao.insertData(homeVo);
		
	}

	public void deleteData(HashMap<String, String> hashMap ) {
		homeDao.deleteData(hashMap);
		
	}

	public void updateData(HomeVo homeVo) {
		homeDao.updateData(homeVo);
		
	}

	public HomeVo selectMember(String id) {
		return homeDao.selectMember(id);
	}*/
	
	
	
}
