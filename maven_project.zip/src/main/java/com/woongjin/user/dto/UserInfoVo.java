package com.woongjin.user.dto;

import java.io.Serializable;

public class UserInfoVo implements Serializable {

	private static final long serialVersionUID = 3367965360895211587L;
	private String userId;
	private String password;
	private String userName;


	public String getUserId() {
		return userId;
	}
	public void setUserId(String userId) {
		this.userId = userId;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	
	
}
