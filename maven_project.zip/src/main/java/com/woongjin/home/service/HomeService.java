package com.woongjin.home.service;

import java.util.HashMap;
import java.util.List;

import org.springframework.stereotype.Service;

import com.woongjin.home.vo.HomeVo;
import com.woongjin.util.Search;
@Service
public interface HomeService {
	public List<HomeVo> selectList(Search paging);
	public int selectListCount(Search search);
	public void insertData(HomeVo homeVo);
	public void deleteData(HashMap<String, String> hashMap);
	public void updateData(HomeVo homeVo);
	public HomeVo selectMember(String id);

}
