package com.woongjin.home.service;

import java.util.ArrayList;

import org.springframework.ui.Model;

import com.woongjin.home.dto.MemberDto;

public class BListService implements BService {

	@Override
	public ArrayList<MemberDto> execute(Model model) {
		// TODO Auto-generated method stub
		return null;
	}
	

}
