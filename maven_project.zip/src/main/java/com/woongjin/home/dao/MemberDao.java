package com.woongjin.home.dao;

public class MemberDao {

}
