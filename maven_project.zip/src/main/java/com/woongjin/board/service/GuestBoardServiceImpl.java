package com.woongjin.board.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.woongjin.board.dao.GuestBoardDao;
import com.woongjin.board.search.GuestBoardSearch;
import com.woongjin.board.vo.GuestBoardVo;

@Service("guestBoardService") 
public class GuestBoardServiceImpl implements GuestBoardService{
	@Autowired
	private GuestBoardDao dao;
	@Override
	public List<GuestBoardVo> selectList(GuestBoardSearch search) {
		// TODO Auto-generated method stub
		return dao.selectList(search);
	}

	@Override
	public int selectListCount(GuestBoardSearch search) {
		// TODO Auto-generated method stub
		return dao.selectListCount(search);
	}

	@Override
	public String selectLastRecord() {
		// TODO Auto-generated method stub
		return dao.selectLastRecord();
	}

	@Override
	public GuestBoardVo select(GuestBoardVo vo) {
		// TODO Auto-generated method stub
		return dao.select(vo);
	}

	@Override
	public void insert(GuestBoardVo vo) {
		dao.insert(vo);
		
	}

	@Override
	public void delete(GuestBoardVo vo) {
		dao.delete(vo);
		
	}

	@Override
	public void update(GuestBoardVo vo) {
		dao.update(vo);
		
	}

}
