package com.woongjin.board.dao;

import java.util.List;

import javax.annotation.Resource;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.woongjin.board.search.GuestBoardSearch;
import com.woongjin.board.vo.GuestBoardVo;
@Repository
public class GuestBoardDaoImpl implements GuestBoardDao {
	@Autowired
	@Resource(name="sqlSessionTemplate")
	private SqlSession query;
	private final static String MAPPER = "board.guestBookDao.";
	@Override
	public List<GuestBoardVo> selectList(GuestBoardSearch search) {
		// TODO Auto-generated method stub
		return query.selectList(MAPPER+"selectList",search);
	}

	@Override
	public int selectListCount(GuestBoardSearch search) {
		// TODO Auto-generated method stub
		return query.selectOne(MAPPER+"selectListCount",search);
	}

	@Override
	public String selectLastRecord() {
		// TODO Auto-generated method stub
		return query.selectOne(MAPPER+"selectLastRecord");
	}

	@Override
	public GuestBoardVo select(GuestBoardVo vo) {
		// TODO Auto-generated method stub
		return query.selectOne(MAPPER+"select",vo);
	}

	@Override
	public void insert(GuestBoardVo vo) {
		query.insert(MAPPER+"insert",vo);
		
	}

	@Override
	public void delete(GuestBoardVo vo) {
		query.delete(MAPPER+"delete",vo);
		
	}

	@Override
	public void update(GuestBoardVo vo) {
		query.update(MAPPER+"update",vo);
		
	}

}
