package com.woongjin.board.controller;

import java.util.HashMap;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.woongjin.board.search.GuestBoardSearch;
import com.woongjin.board.service.GuestBoardService;
import com.woongjin.board.vo.GuestBoardVo;
import com.woongjin.util.EncryptUtil;

@Controller
@RequestMapping(value="/board")
public class GuestBoardController {
	@Autowired
	private GuestBoardService guestBoardService;
	
	@RequestMapping(value="/list.do")
	public ModelAndView list(GuestBoardSearch search) {
		
		search.calculate(guestBoardService.selectListCount(search));
		ModelAndView view = new ModelAndView("/board/board_main");

		view.addObject("search",search);
/*		List<GuestBoardVo> gestVo=guestBoardService.selectList(search);
		for(GuestBoardVo vo : gestVo) {
			System.out.println("getGuestBookId = "+ vo.getGuestBookId()); 
		}*/
		view.addObject("list",guestBoardService.selectList(search));
		return view;
	}
	
	
	@RequestMapping(value="/insertForm.do")
	public String insertForm() {

		return "/board/insertForm";
	}
	@RequestMapping(value="/insert.do")
	public String insert(GuestBoardVo guestBoardVo) throws Exception {
		guestBoardVo.setGuestBookId(createID());
		guestBoardVo.setPassword(EncryptUtil.getEncMD5(guestBoardVo.getPassword()));
		guestBoardService.insert(guestBoardVo);
	
		return "redirect:/board/list.do";
	}
	
	@RequestMapping(value="/passwordCheck.do")
	public @ResponseBody Map<String,String> passwordCheck(GuestBoardVo guestBoardVo) throws Exception {

		Map<String, String> resultMap = new HashMap<String, String>();		
		guestBoardVo.setPassword(EncryptUtil.getEncMD5(guestBoardVo.getPassword()));
		GuestBoardVo resultVo = guestBoardService.select(guestBoardVo);
		if(resultVo != null) {
			resultMap.put("guestBookId", resultVo.getGuestBookId());
		}
	
		return resultMap;
	}
	@RequestMapping(value="/modifyForm.do")
	public ModelAndView modifyForm(GuestBoardVo guestBoardVo) throws Exception {
		String paramPw = guestBoardVo.getPassword();
		guestBoardVo.setPassword(EncryptUtil.getEncMD5(guestBoardVo.getPassword()));
		GuestBoardVo resultVo = guestBoardService.select(guestBoardVo);
		if(resultVo != null) {
			ModelAndView view = new ModelAndView("/board/modifyForm");
			resultVo.setPassword(paramPw);
			System.out.println(resultVo.getRegisterName() +"   "+resultVo.getPassword());
			view.addObject("data", resultVo);
			return view;
		}else {
			ModelAndView view = new ModelAndView("redirect:/board/list.do");
			return view;
		}
	
		
	}
	@RequestMapping(value="/update.do")
	public ModelAndView update(GuestBoardVo guestBoardVo) throws Exception {
	
		guestBoardVo.setPassword(EncryptUtil.getEncMD5(guestBoardVo.getPassword()));
		guestBoardService.update(guestBoardVo);

		ModelAndView view = new ModelAndView("redirect:/board/list.do");
		return view;
		
	}
	
	
	@RequestMapping(value="/delete.do")
	public ModelAndView delete(GuestBoardVo guestBoardVo) throws Exception {
	
		guestBoardVo.setPassword(EncryptUtil.getEncMD5(guestBoardVo.getPassword()));
		GuestBoardVo resultVo = guestBoardService.select(guestBoardVo);
		if(resultVo != null) {
			guestBoardService.delete(resultVo);
			ModelAndView view = new ModelAndView("redirect:/board/list.do");
			return view;
		}else {
			ModelAndView view = new ModelAndView("redirect:/board/list.do");
			return view;
		}
	
		
	}
	
	public String createID() {


		String columId = guestBoardService.selectLastRecord();
		String substring_int_columId = columId.substring(5,columId.length() );
		String substring_str_columId = columId.substring(0,5);
		
		int transInt_surId = Integer.parseInt(substring_int_columId);

		String prefix = String.format("%04d",transInt_surId+1); 
		columId=substring_str_columId+prefix;
		
		return columId;
	}
}
