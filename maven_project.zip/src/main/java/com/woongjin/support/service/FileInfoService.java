package com.woongjin.support.service;

import java.io.FileInputStream;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.web.multipart.MultipartFile;

import com.woongjin.support.vo.FileInfoVo;
import com.woongjin.util.Search;

public interface FileInfoService {
	public List<FileInfoVo> selectList();
	public int selectListCount(Search search);
	public List<FileInfoVo> insert(List<MultipartFile> multipartFiles);
	public FileInfoVo insert(MultipartFile multipartFile);
	public FileInfoVo select(String fileId);
	public void delete(String fileId);
	
	public void downloadFile(HttpServletRequest request,HttpServletResponse response, String fileId);
	public void downloadFile(HttpServletRequest request,HttpServletResponse response, String downloadFileName,FileInputStream fin);
	

}
