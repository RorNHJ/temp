package com.woongjin.support.service;

import java.io.File;
import java.io.FileInputStream;
import java.nio.channels.Channels;
import java.nio.channels.FileChannel;
import java.nio.channels.WritableByteChannel;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.UUID;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang.time.DateFormatUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import com.mysql.jdbc.StringUtils;
import com.woongjin.support.controller.BaseService;
import com.woongjin.support.dao.FileInfoDao;
import com.woongjin.support.vo.FileInfoVo;
import com.woongjin.util.HttpUtil;
import com.woongjin.util.Search;
import com.woongjin.util.exception.GenericException;

@Service("fileInfoService") 
public class FileInfoServiceImpl extends BaseService implements FileInfoService {

	@Value ("${file.root.path}")
	private String rootPath;
	
	@Autowired
	private FileInfoDao dao;

	@Override
	public List<FileInfoVo> selectList() {
		// TODO Auto-generated method stub
		return dao.selectList();
	}

	@Override
	public int selectListCount(Search search) {
		// TODO Auto-generated method stub
		return dao.selectListCount(search);
	}
	@Override
	public FileInfoVo select(String fileId) {
		// TODO Auto-generated method stub
		return dao.select(fileId);
	}

	@Override
	public void delete(String fileId) {
		FileInfoVo vo = dao.select(fileId);
		String fullPath = rootPath + vo.getFilePath() +  vo.getFileId();
		File file= new File(fullPath);
		if(!file.exists()) {
			throw new GenericException("file","파일이 없습니다");
			
		}
		if(file.delete()) {
			dao.delete(fileId);
		}else {
			throw new GenericException("file","파일 삭제에 실패했습니다.");
		}
		
		
	}
	@Override
	public List<FileInfoVo> insert(List<MultipartFile> multipartFiles) {
		List<FileInfoVo> voList = new ArrayList<FileInfoVo>();
		for(MultipartFile multipartFile : multipartFiles) {
			voList.add(insert(multipartFile));

		}
		return voList;
	}

	@Override
	public FileInfoVo insert(MultipartFile multipartFile) {
		String orgFileName = multipartFile.getOriginalFilename();
		String contentType =  multipartFile.getContentType();
		long fileSize =multipartFile.getSize();
		String fileId= UUID.randomUUID().toString().replace("-", "");
		String dirPath = DateFormatUtils.format(new Date(), "yyyy/MM/dd/");
		String fullPath =  rootPath + dirPath;
		
		File dir = new File(fullPath);
		if(!dir.isDirectory()) dir.mkdirs();
		
		String path = fullPath + fileId;
		File f = new File(path);
		try {
			multipartFile.transferTo(f);
		} catch (Exception e) {
			throw new GenericException("file", e.toString());
		}
		FileInfoVo vo = new FileInfoVo();
		vo.setFileId(fileId);
		vo.setOrgFileName(orgFileName);
		vo.setContentType(contentType);
		vo.setFileSize(fileSize);
		vo.setFilePath(dirPath);
		vo.setRegistId((String) getRequestAttribut("userId"));
		
		dao.insert(vo);
		return vo;
	}



	@Override
	public void downloadFile(HttpServletRequest request,HttpServletResponse response, String fileId) {
		FileInfoVo vo =dao.select(fileId);
		
		String downloadFileName = vo.getOrgFileName();
		String fullPath = rootPath+vo.getFilePath() + vo.getFileId();
		File downloadFile = new File(fullPath);
		try {
			
			FileInputStream fin = new FileInputStream(downloadFile);
			downloadFile(request,response,downloadFileName,fin);
			
			
		} catch (Exception e) {
			throw new GenericException("file", e.toString());
		}
		
	}

	@Override
	public void downloadFile(HttpServletRequest request,HttpServletResponse response, String downloadFileName, FileInputStream fin) {
		FileChannel source = null;
		WritableByteChannel destination = null;
		
		try {
			downloadFileName = HttpUtil.getDisposition(downloadFileName, HttpUtil.getBrowser(request));
			
			source = fin.getChannel();
			destination = Channels.newChannel(response.getOutputStream());
			if(StringUtils.isEmptyOrWhitespaceOnly(response.getContentType()) || response.getContentType().indexOf("/") ==-1) {
				response.setContentType("application/x-msdownlaod");
			}
			response.setHeader("Content-Disposition", "attachment;filename="+downloadFileName+";");
			source.transferTo(0, fin.available(), destination);
		} catch (Exception e) {
			throw new GenericException("file", e.toString());
		}finally {
			try {
				if(fin != null) {
					fin.close();
				}
				if(source != null) {
					source.close();
				}
				if(destination != null) {
					destination.close();
				}				
			}catch (Exception e) {
				throw new GenericException("file", e.toString());
			}
		}
		
	}
	
	
	

}
