package com.woongjin.intern.survey.dto;

public class AnswerVo {
	private String aswId;
	private String surId;
	private String qstI;
	private String aswCont;
	public String getAswId() {
		return aswId;
	}
	public void setAswId(String aswId) {
		this.aswId = aswId;
	}
	public String getSurId() {
		return surId;
	}
	public void setSurId(String surId) {
		this.surId = surId;
	}
	public String getQstI() {
		return qstI;
	}
	public void setQstI(String qstI) {
		this.qstI = qstI;
	}
	public String getAswCont() {
		return aswCont;
	}
	public void setAswCont(String aswCont) {
		this.aswCont = aswCont;
	}
	
	
}
