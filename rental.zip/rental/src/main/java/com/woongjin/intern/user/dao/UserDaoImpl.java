package com.woongjin.intern.user.dao;

import java.util.List;

import javax.annotation.Resource;

import org.apache.ibatis.session.SqlSession;
import org.mybatis.spring.SqlSessionTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.woongjin.intern.user.vo.UserVo;

@Repository
public class UserDaoImpl implements UserDao {
	@Autowired
	@Resource(name="sqlSessionTemplate")
    private SqlSession query;
	private final static String Mapper = "user.userDao.";
	
	
	@Override
	public void insert(UserVo vo) {
		query.insert(Mapper+"insert", vo);
		
	}

	@Override
	public void update(UserVo vo) {
		query.update(Mapper+"update",vo);
		
	}


	@Override
	public UserVo select(String userId) {
		// TODO Auto-generated method stub
		return query.selectOne(Mapper+"select",userId);
	}



	@Override
	public void delete(String string) {
		query.delete(Mapper+"delete",string);
		
	}

	
	
	

}
