package com.woongjin.intern.survey.dto;

import java.util.ArrayList;

public class ModifyVo {
	private String surId;
	private ArrayList<String> aswId;
	private ArrayList<String> qstId;
	private String surTitle;
	private ArrayList<String> qstCont;
	private ArrayList<String> aswCont;
	public String getSurId() {
		return surId;
	}
	public void setSurId(String surId) {
		this.surId = surId;
	}
	public ArrayList<String> getAswId() {
		return aswId;
	}
	public void setAswId(ArrayList<String> aswId) {
		this.aswId = aswId;
	}
	public ArrayList<String> getQstId() {
		return qstId;
	}
	public void setQstId(ArrayList<String> qstId) {
		this.qstId = qstId;
	}
	public String getSurTitle() {
		return surTitle;
	}
	public void setSurTitle(String surTitle) {
		this.surTitle = surTitle;
	}
	public ArrayList<String> getQstCont() {
		return qstCont;
	}
	public void setQstCont(ArrayList<String> qstCont) {
		this.qstCont = qstCont;
	}
	public ArrayList<String> getAswCont() {
		return aswCont;
	}
	public void setAswCont(ArrayList<String> aswCont) {
		this.aswCont = aswCont;
	}
	

}
