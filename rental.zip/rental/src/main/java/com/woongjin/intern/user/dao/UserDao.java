package com.woongjin.intern.user.dao;

import java.util.List;
import com.woongjin.intern.user.vo.UserVo;
public interface UserDao {

	public void insert(UserVo userInfoVo);
	public void update(UserVo userInfoVo);
	public void delete(String userId);
	public UserVo select(String userId);
}
