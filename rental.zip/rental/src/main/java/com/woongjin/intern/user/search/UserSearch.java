package com.woongjin.intern.user.search;

import com.woongjin.intern.util.Search;

public class UserSearch extends Search {

}
