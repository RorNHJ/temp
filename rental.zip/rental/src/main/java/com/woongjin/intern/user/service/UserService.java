package com.woongjin.intern.user.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.woongjin.intern.user.vo.UserVo;

@Service
public interface UserService {
	public void insert(UserVo userInfoVo);
	public void update(UserVo userInfoVo);
	public void delete(String userId);
	public UserVo select(String userId);
}
