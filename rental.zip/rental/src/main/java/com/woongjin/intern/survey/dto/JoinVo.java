package com.woongjin.intern.survey.dto;

public class JoinVo {
	private String surId;
	private String surTitle;
	private String qstId;
	private String qstCont;
	private String aswId;
	private String aswCont;
	public String getSurId() {
		return surId;
	}
	public void setSurId(String surId) {
		this.surId = surId;
	}
	public String getSurTitle() {
		return surTitle;
	}
	public void setSurTitle(String surTitle) {
		this.surTitle = surTitle;
	}
	public String getQstId() {
		return qstId;
	}
	public void setQstId(String qstId) {
		this.qstId = qstId;
	}
	public String getQstCont() {
		return qstCont;
	}
	public void setQstCont(String qstCont) {
		this.qstCont = qstCont;
	}
	public String getAswId() {
		return aswId;
	}
	public void setAswId(String aswId) {
		this.aswId = aswId;
	}
	public String getAswCont() {
		return aswCont;
	}
	public void setAswCont(String aswCont) {
		this.aswCont = aswCont;
	}
	
}
