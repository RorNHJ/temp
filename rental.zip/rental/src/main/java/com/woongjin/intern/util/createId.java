package com.woongjin.intern.util;

public class createId {

}
