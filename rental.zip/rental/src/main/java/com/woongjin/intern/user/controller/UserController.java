package com.woongjin.intern.user.controller;

import java.util.Locale;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.woongjin.intern.user.service.UserService;
import com.woongjin.intern.user.vo.UserVo;

@Controller
@RequestMapping(value = "/user")
public class UserController {
	@Autowired
	private UserService userService;
	
	
	
	@RequestMapping(value = "/woongjin_join.do", method = RequestMethod.POST)
	public String woongjin_join(UserVo vo) {
		vo.setPlatform("woongjin");
		userService.insert(vo);

		return "/login/login_view";
	}
}
