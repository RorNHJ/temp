package com.woongjin.intern.survey.dto;

public class SurveyVo {
	private String surId;
	private int surIndex;
	private String surTitle;
	private String surUse;
	public String getSurId() {
		return surId;
	}
	public void setSurId(String surId) {
		this.surId = surId;
	}
	public int getSurIndex() {
		return surIndex;
	}
	public void setSurIndex(int surIndex) {
		this.surIndex = surIndex;
	}
	public String getSurTitle() {
		return surTitle;
	}
	public void setSurTitle(String surTitle) {
		this.surTitle = surTitle;
	}
	public String getSurUse() {
		return surUse;
	}
	public void setSurUse(String surUse) {
		this.surUse = surUse;
	}
	
	
}
