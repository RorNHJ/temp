package com.woongjin.intern.user.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.woongjin.intern.user.dao.UserDao;
import com.woongjin.intern.user.dao.UserDaoImpl;
import com.woongjin.intern.user.vo.UserVo;

@Service("userService")
public class UserServiceImpl implements UserService{
	@Autowired
	private UserDaoImpl Dao;


	@Override
	public void insert(UserVo userInfoVo) {
		Dao.insert(userInfoVo);
		
	}

	@Override
	public void update(UserVo userInfoVo) {
		Dao.update(userInfoVo);
		
	}

	@Override
	public void delete(String string) {
		Dao.delete(string);
		
	}

	@Override
	public UserVo select(String userId) {
		// TODO Auto-generated method stub
		return Dao.select(userId);
	}


	
	
	
	
	
	
	
	

/*	public List<HomeVo> selectList(Search paging){
//		homeDao= new HomeDaoImpl();
		return homeDao.selectList(paging);
	}

	public int selectListCount(Search search) {
		// TODO Auto-generated method stub
		return homeDao.selectListCount(search);
	}

	public void insertData(HomeVo homeVo) {
		homeDao.insertData(homeVo);
		
	}

	public void deleteData(HashMap<String, String> hashMap ) {
		homeDao.deleteData(hashMap);
		
	}

	public void updateData(HomeVo homeVo) {
		homeDao.updateData(homeVo);
		
	}

	public HomeVo selectMember(String id) {
		return homeDao.selectMember(id);
	}*/
	
	
	
}
