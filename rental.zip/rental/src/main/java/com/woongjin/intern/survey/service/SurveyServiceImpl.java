package com.woongjin.intern.survey.service;

import java.util.HashMap;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.woongjin.intern.survey.dao.SurveyDao;
import com.woongjin.intern.survey.dto.AnswerVo;
import com.woongjin.intern.survey.dto.InsertVo;
import com.woongjin.intern.survey.dto.JoinVo;
import com.woongjin.intern.survey.dto.QuestionVo;
import com.woongjin.intern.survey.dto.SurveyVo;

@Service("surveyService")  //MServic memberService = new MemberService(); 而⑦듃濡ㅻ윭�뿉�꽌�뒗 @Resource(name ="memberService")
public class SurveyServiceImpl implements SurveyService{
	@Autowired
	private SurveyDao dao;

	@Override
	public List<SurveyVo> selectSurvey() {
		// TODO Auto-generated method stub
		return dao.selectSurvey();
	}

	@Override
	public SurveyVo selectOneSurvey(String surTitle) {
		// TODO Auto-generated method stub
		return dao.selectOneSurvey(surTitle);
	}

	@Override
	public List<JoinVo> join(String surId) {
		// TODO Auto-generated method stub
		return dao.join(surId);
	}

	@Override
	public List<QuestionVo> selectQuestion(String surId) {
		// TODO Auto-generated method stub
		return dao.selectQuestion(surId);
	}

	@Override
	public void uploadSurvey(SurveyVo vo) {
		dao.uploadSurvey(vo);
		
	}

	@Override
	public void uploadQuestion(QuestionVo vo) {
		dao.uploadQuestion(vo);
		
	}

	@Override
	public void uploadAnswer(AnswerVo vo) {
		// TODO Auto-generated method stub
		dao.uploadAnswer(vo);
	}

	@Override
	public String selectLastRecord(HashMap<String, String> table_name) {
		// TODO Auto-generated method stub
		return dao.selectLastRecord(table_name);
	}

	@Override
	public void insertSurvey(InsertVo vo) {
		dao.insertSurvey(vo);
	}

	@Override
	public void insertQuestion(InsertVo vo) {
		dao.insertQuestion(vo);
		
	}

	@Override
	public void insertAnswer(InsertVo vo) {
		dao.insertAnswer(vo);
		
	}

	
	
	
	@Override
	public List<SurveyVo> selectTest() {
		// TODO Auto-generated method stub
		return dao.selectTest();
	}
	
	
	
	

	
	
	

	



}
