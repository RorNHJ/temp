package com.woongjin.intern.survey.dto;

import java.util.ArrayList;

public class InsertVo {
	private String surId;
	private String surTitle;
	private String qstId;
	private ArrayList<String> qstContList;
	private ArrayList<String> aswContList;
	private String qstCont;
	private String aswId;
	private String aswCont;
	public String getSurTitle() {
		return surTitle;
	}
	public void setSurTitle(String surTitle) {
		this.surTitle = surTitle;
	}
	
	public ArrayList<String> getQstContList() {
		return qstContList;
	}
	public void setQstContList(ArrayList<String> qstContList) {
		this.qstContList = qstContList;
	}
	
	public String getQstCont() {
		return qstCont;
	}
	public void setQstCont(String qstCont) {
		this.qstCont = qstCont;
	}

	public ArrayList<String> getAswContList() {
		return aswContList;
	}
	public void setAswContList(ArrayList<String> aswContList) {
		this.aswContList = aswContList;
	}
	public String getAswCont() {
		return aswCont;
	}
	public void setAswCont(String aswCont) {
		this.aswCont = aswCont;
	}
	public String getSurId() {
		return surId;
	}
	public void setSurId(String surId) {
		this.surId = surId;
	}
	public String getQstId() {
		return qstId;
	}
	public void setQstId(String qstId) {
		this.qstId = qstId;
	}
	public String getAswId() {
		return aswId;
	}
	public void setAswId(String aswId) {
		this.aswId = aswId;
	}
	
	
	
}
