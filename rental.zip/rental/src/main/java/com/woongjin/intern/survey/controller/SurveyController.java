package com.woongjin.intern.survey.controller;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;

import org.apache.ibatis.annotations.Insert;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.woongjin.intern.survey.dao.SurveyDao;
import com.woongjin.intern.survey.dto.AnswerVo;
import com.woongjin.intern.survey.dto.InsertVo;
import com.woongjin.intern.survey.dto.JoinVo;
import com.woongjin.intern.survey.dto.ModifyVo;
import com.woongjin.intern.survey.dto.QuestionVo;
import com.woongjin.intern.survey.dto.SurveyVo;
import com.woongjin.intern.survey.service.SurveyService;

@Controller
@RequestMapping("/survey")
public class SurveyController {
	@Autowired

	@Resource(name ="surveyService")
	private SurveyService surveyService;
/*
	
	@RequestMapping(value="/surveylist.do")
	public ModelAndView surveylist() {
		ModelAndView view = new ModelAndView("main");
		view.addObject("question",surveyService.selectQuestion());
		view.addObject("subject",surveyService.selectSubject());
		view.addObject("option",surveyService.selectAll());
		return view;
	}*/
	@RequestMapping(value="/survey_view.do")
	public ModelAndView survey_view() {
		System.out.println("111");
		ModelAndView view = new ModelAndView("/survey/survey_view");
		System.out.println("222");
		
		view.addObject("survey",surveyService.selectSurvey());
		System.out.println("333");
		return view;
	}
	@RequestMapping(value="/survey/insertForm.do")
	public ModelAndView insertForm() {
		ModelAndView view = new ModelAndView("/survey/insertForm");
		return view;
	}
	@RequestMapping(value="/survey/modifySurvey_view.do")
	public ModelAndView modifySurvey_view(HttpServletRequest request) {
		String surId = request.getParameter("selectedSurvey");
		String surTitle = null;
		ModelAndView view = new ModelAndView("/survey/modifySurvey");
		List<JoinVo> joinVo = surveyService.join(surId);
		surTitle = joinVo.get(0).getSurTitle();
	
		view.addObject("surveyId", surId);
		view.addObject("surveyTitle", surTitle);
		view.addObject("answer",surveyService.join(surId));
		view.addObject("question",surveyService.selectQuestion(surId));
		return view;
	}
	@RequestMapping(value="/modify.do")
	public String modify(ModifyVo modifyVo) {
		/*
		System.out.println("ccc:  " + vo.getAswId() + vo.getQstId() + vo.getSurId() + vo.getSurTitle());
		System.out.println("surId: "+ vo.getSurId());
		System.out.println("surveyTitle: "+ vo.getSurTitle());
		for(String aa: vo.getQstId()) {
			
			System.out.println("getQstId: "+ aa);
		}
		for(String aa: vo.getQstCont()) {
			
			System.out.println("getQstCont: "+ aa);
		}
		for(String aa: vo.getAswId()) {
			
			System.out.println("getAswId: "+ aa);
		}
		
		for(String aa: vo.getAswCont()) {
			System.out.println("getAswCont: "+ aa);
		}*/
		SurveyVo surveyVo = new SurveyVo();
		QuestionVo questionVo = new QuestionVo();
		AnswerVo answerVo = new AnswerVo();
		
		surveyVo.setSurId(modifyVo.getSurId());
		surveyVo.setSurTitle(modifyVo.getSurTitle());
		System.out.println("surveyTitle: "+ surveyVo.getSurTitle());
		surveyService.uploadSurvey(surveyVo);
		
		for(String qstCont: modifyVo.getQstCont()) {
			questionVo.setQstId(modifyVo.getQstId().get(0));
			questionVo.setQstCont(qstCont);
			surveyService.uploadQuestion(questionVo);
		}
		
		for(int i = 0; i < modifyVo.getAswId().size(); i++) {
			answerVo.setAswId(modifyVo.getAswId().get(i));
			answerVo.setAswCont(modifyVo.getAswCont().get(i));
			surveyService.uploadAnswer(answerVo);
		}
		
		return "/main/main";
	}
	@RequestMapping(value="/survey/insert.do")
	public String insert(InsertVo vo) {

		
		vo.setSurId(createID("survey", "SUR_ID"));
		surveyService.insertSurvey(vo);
		
		

		for(String qstCont : vo.getQstContList()) {
			vo.setQstId(createID("question", "QST_ID"));
			vo.setQstCont(qstCont);
			surveyService.insertQuestion(vo);
		}
		for(String aswCont: vo.getAswContList()) {
			vo.setAswId(createID("answer", "ASW_ID"));
			vo.setAswCont(aswCont);
			surveyService.insertQuestion(vo);
		}

		surveyService.insertAnswer(vo);
		
		
		return("redirect:/survey_view.do");
	}
	
	public String createID(String parmaTable, String paramId) {

		HashMap<String, String> table= new HashMap<String, String>();
		table.put("parmaTable", parmaTable);
		table.put("paramId", paramId);
	
		String columId = surveyService.selectLastRecord(table);
		String substring_int_columId = columId.substring(1,columId.length() );
		String substring_str_columId = columId.substring(0,1);
		
		int transInt_surId = Integer.parseInt(substring_int_columId);

		String prefix = String.format("%04d",transInt_surId+1); 
		columId=substring_str_columId+prefix;
		
		
		
		return columId;
	}
}
