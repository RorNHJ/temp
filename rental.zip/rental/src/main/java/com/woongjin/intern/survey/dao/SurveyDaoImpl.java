package com.woongjin.intern.survey.dao;

import java.util.HashMap;
import java.util.List;

import javax.annotation.Resource;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.woongjin.intern.survey.dto.AnswerVo;
import com.woongjin.intern.survey.dto.InsertVo;
import com.woongjin.intern.survey.dto.JoinVo;
import com.woongjin.intern.survey.dto.QuestionVo;
import com.woongjin.intern.survey.dto.SurveyVo;

@Repository
public class SurveyDaoImpl implements SurveyDao {

	@Autowired
	@Resource(name="sqlSessionTemplate")
	private SqlSession query;
	private final static String MAPPER = "survey.surveyDao.";

	@Override
	public List<SurveyVo> selectSurvey() {
		List<SurveyVo> list = query.selectList(MAPPER+"selectSurvey");
		
		return list;
	}
	@Override
	public SurveyVo selectOneSurvey(String surTitle) {
		// TODO Auto-generated method stub
		return query.selectOne(MAPPER+"selectOneSurvey");
	}
	@Override
	public List<JoinVo> join(String surId) {
		System.out.println(surId);
		return query.selectList(MAPPER+"join",surId);
	}
	@Override
	public List<QuestionVo> selectQuestion(String surId) {
		// TODO Auto-generated method stub
		return query.selectList(MAPPER+"selectQuestion",surId);
	}
	@Override
	public void uploadSurvey(SurveyVo vo) {
		query.update(MAPPER+"uploadSurvey",vo);
		
	}
	@Override
	public void uploadQuestion(QuestionVo vo) {
		query.update(MAPPER+"uploadQuestion",vo);		
	}
	@Override
	public void uploadAnswer(AnswerVo vo) {
		query.update(MAPPER+"uploadAnswer",vo);		
	}
	@Override
	public String selectLastRecord(HashMap<String, String> table_name) {
		// TODO Auto-generated method stub
		return query.selectOne(MAPPER+"uploadAnswer",table_name);	
	}
	@Override
	public void insertSurvey(InsertVo vo) {
		// TODO Auto-generated method stub
		query.insert(MAPPER+"insertSurvey",vo);	
	}
	@Override
	public void insertQuestion(InsertVo vo) {
		query.insert(MAPPER+"insertQuestion",vo);	
		
	}
	@Override
	public void insertAnswer(InsertVo vo) {
		query.insert(MAPPER+"insertAnswer",vo);	
		
	}
	
	
	
	@Override
	public List<SurveyVo> selectTest() {
		// TODO Auto-generated method stub
		return query.selectList(MAPPER+"selectTest");
	}
	

	


}
