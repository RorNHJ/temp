package com.woongjin.intern.login.controller;

import java.util.Locale;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

@Controller
@RequestMapping(value = "/login")
public class LoginController {
	@RequestMapping(value = "/login_view.do", method = RequestMethod.GET)
	public String login_view(Locale locale, Model model) {

		
		return "/login/login_view";
	}
	@RequestMapping(value = "/join_view.do", method = RequestMethod.GET)
	public String join_view(Locale locale, Model model) {

		
		return "/login/join_view";
	}
}
