package com.woongjin.intern.survey.service;

import java.util.HashMap;
import java.util.List;

import com.woongjin.intern.survey.dto.AnswerVo;
import com.woongjin.intern.survey.dto.InsertVo;
import com.woongjin.intern.survey.dto.JoinVo;
import com.woongjin.intern.survey.dto.QuestionVo;
import com.woongjin.intern.survey.dto.SurveyVo;

public interface SurveyService {

	public List<SurveyVo> selectSurvey();
	public List<SurveyVo> selectTest();
	
	
	
	public SurveyVo selectOneSurvey(String surTitle);
	public List<JoinVo> join (String surId);
	public List<QuestionVo> selectQuestion (String surId);
	public void uploadSurvey(SurveyVo vo);
	public void uploadQuestion(QuestionVo vo);
	public void uploadAnswer(AnswerVo vo);
	public String selectLastRecord(HashMap<String, String> table_name);
	public void insertSurvey(InsertVo vo);
	public void insertQuestion(InsertVo vo);
	public void insertAnswer(InsertVo vo);

} 
