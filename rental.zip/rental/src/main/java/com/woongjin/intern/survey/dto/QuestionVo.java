package com.woongjin.intern.survey.dto;

public class QuestionVo {
	private String qstId;
	private String surId;
	private int qstIndex;
	private String qstCont;
	public String getQstId() {
		return qstId;
	}
	public void setQstId(String qstId) {
		this.qstId = qstId;
	}
	public String getSurId() {
		return surId;
	}
	public void setSurId(String surId) {
		this.surId = surId;
	}
	public int getQstIndex() {
		return qstIndex;
	}
	public void setQstIndex(int qstIndex) {
		this.qstIndex = qstIndex;
	}
	public String getQstCont() {
		return qstCont;
	}
	public void setQstCont(String qstCont) {
		this.qstCont = qstCont;
	}
	
	
}
