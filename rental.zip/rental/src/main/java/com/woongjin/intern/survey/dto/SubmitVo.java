package com.woongjin.intern.survey.dto;

public class SubmitVo {

}
