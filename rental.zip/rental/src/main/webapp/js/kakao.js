Kakao.init('5d04226dec052e14aa8c908347ce7a16');


//공유하기 



// 로그인창 띄어서 로그인 하기
function loginWithKakao() {
	// 로그인 창을 띄웁니다.
	Kakao.Auth.login({
		success : function(authObj) {
			Kakao.API.request({
				url : '/v1/user/me',
				success : function(res) {
					$.ajax({
						type : "post",
						dataType : "json",
						url : "/login/kakao_login.do",
						data : {
							mId : res.id,
							mName : res.properties.nickname
						},
						success : function(data) {
			
							location.href="/main.do?loginName="+data.login.userName;
						},
						error : function(data) {
							alert('error:' + data.result);
						}
					});
				},
				fail : function(error) {
					alert(JSON.stringify(error));
				}
			});

		},
		fail : function(err) {
			alert(JSON.stringify(err));
		}
	});
};