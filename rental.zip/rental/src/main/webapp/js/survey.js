var selectedSurvey;

$('#openSurvey').click(function(){
	$.ajax({
		type : "post",
		dataType : "json",
		url : "/survey/openSurvey.do",
		data : {
			mId : res.id,
			mName : res.properties.nickname
		},
		success : function(data) {

			location.href="/main.do?loginName="+data.login.userName;
		},
		error : function(data) {
			alert('error:' + data.result);
		}
	});
});


function optionSurveySelected(element) {
	selectedSurvey = element.options[element.selectedIndex].text;
    
}
$('#modifySurvey_btn').click(function(){
	alert("click");
	location.replace("survey/modifySurvey_view.do?selectedSurvey="+selectedSurvey);
});
$('#back_btn').click(function(){
	alert("click");
	window.history.back();
});

function add_item(){
    // pre_set 에 있는 내용을 읽어와서 처리..
    var div = document.createElement('div');
    div.innerHTML = document.getElementById('pre_set').innerHTML;
    document.getElementById('field').appendChild(div);
}

function remove_item(obj){
    // obj.parentNode 를 이용하여 삭제
    document.getElementById('field').removeChild(obj.parentNode);
}
